# PROBLEMAS

En el mustPromoteTo, se manda el mensaje del error como this, si quien lo llama es el error, por ejemplo en
la ejecucion del wrong.input.4 del lab 9.
O si por ejemplo intento igualar con una variable que no existe.
Se soluciona si pongo un instanceof this{ return this; }
***
if: estos dos puntos¿¿¿¿¿??? keloke {
}
***
Mirar lo del ambito de las variables, que no se si se esta haciendo o no!!!!!!!
***
***
# PREGUNTAS

