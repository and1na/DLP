package ast.statement;

import ast.node.ASTNode;

public interface Statement extends ASTNode {
    boolean hasReturn();
}
