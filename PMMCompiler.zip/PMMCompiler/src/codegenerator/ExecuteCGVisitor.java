package codegenerator;

import ast.Program;
import ast.definition.FunctionDefinition;
import ast.definition.VarDefinition;
import ast.statement.*;
import ast.type.Function;

//This visitor is in charge of generating the code for the execution of programs (definitions and statements)

public class ExecuteCGVisitor extends AbstractCGVisitor<FunctionDefinition,Void>{

    private final AddressCGVisitor addressVisitor;
    private final ValueCGVisitor valueVisitor;

    public ExecuteCGVisitor(CodeGenerator codeGenerator) {
        super(codeGenerator);
        this.addressVisitor = new AddressCGVisitor(codeGenerator);
        this.valueVisitor = new ValueCGVisitor(codeGenerator);
        addressVisitor.setValueVisitor(valueVisitor);
        valueVisitor.setAddressVisitor(addressVisitor);
    }


    //VISIT FOR PROGRAM
    @Override
    public Void visit(Program node, FunctionDefinition param) {
        node.getVarDefinitions().forEach(vDef -> vDef.accept(this,param));
        cg.call("main");
        cg.halt();
        node.getFunctionDefinitions().forEach(fDef -> fDef.accept(this,param));
        return null;
    }

    //VISIT FOR FUNCTION DEFINITION
    @Override
    public Void visit(FunctionDefinition node, FunctionDefinition param) {
        //Line Comment
        cg.lineComment(node.getLine());
        //Label
        cg.label(node.getName());
        //Params comment
        cg.comment("Params");
        ((Function)node.getType()).getParameters().forEach(p -> p.accept(this,node));
        //Locals comment
        cg.comment("Locals");
        node.getBodyVarDefinitions().forEach(vDef -> vDef.accept(this,node));

        //BytesLocals is the same as the offset of the last variable * -1
        int bytesLocals = node.getBodyVarDefinitions().isEmpty() ? 0 : -node.getBodyVarDefinitions()
                .get(node.getBodyVarDefinitions().size()-1)
                .getOffset();

        //Allocate space for locals

        /*
            The parameters are already stacked in the stack due to the function call.

            Local variables are "assigned" with the instruction; the total number of bytes must be passed as a parameter

            **(what actually happens is that space is reserved for these variables, then, thanks to the offset of each
            one in its definition, we will know where in the stack to store the value given in an assignment or
            where to look for it in the value visitor)
        */
        cg.enter(bytesLocals);

        int bytesParams = ((Function) node.getType())
                .getParameters()
                .stream()
                .mapToInt(v -> v.getType().numberOfBytes()).sum();

        int bytesReturn = ((Function) node.getType()).getReturnType().numberOfBytes();

        //Statements execution
        //From this moment on, the funcDef is passed down  through the tree, we'll need it in the return statement
        node.getStatements().forEach(statement -> statement.accept(this,node));

        //Add ret instruction if no return statement is found (void returnType = 0)
        if (bytesReturn == 0) cg.ret(0, bytesLocals, bytesParams);

        return null;
    }

    //VISIT FOR FUNCTIONTYPE
    public Void visit(Function node, FunctionDefinition param) {
        //Comments of the parameters
        node.getParameters().forEach(varDef -> varDef.accept(this, param));
        return null;
    }

    //VISIT FOR VARDEFINITION
    public Void visit(VarDefinition node, FunctionDefinition param) {
        //Comment
        cg.comment( node.getType().toString() + " " + node.getName()
                + "(offset " + node.getOffset() + ")");
        return null;
    }

    //VISIT FOR STATEMENTS
        //VISIT FOR ASSIGNMENT
    public Void visit(Assignment node, FunctionDefinition param) {
        //Comments
        cg.lineComment(node.getLine());
        cg.comment("Assignment");
        //Address and value visitors
        node.getVar().accept(addressVisitor,param);//puts the address of the variable in the stack
        node.getValue().accept(valueVisitor,param);//puts the value of the expression in the stack
        //This conversion is necessary because we could have an int assigned to a double, for example
        cg.convert(node.getValue().getType(),node.getVar().getType());
        cg.store(node.getVar().getType());
        return null;
    }
        //VISIT FOR PRINT
    public Void visit(Print node, FunctionDefinition param) {
        //Comments
        cg.lineComment(node.getLine());
        cg.comment("Print");
        node.getExpressionToPrint().accept(valueVisitor,param);
        cg.out(node.getExpressionToPrint().getType());
        return null;
    }
        //VISIT FOR INPUT
    public Void visit(Input node, FunctionDefinition param) {
        //Comments
        cg.lineComment(node.getLine());
        cg.comment("Read");
        node.getInputExpression().accept(addressVisitor, param);
        cg.in(node.getInputExpression().getType());
        cg.store(node.getInputExpression().getType());
        return null;
    }

    //VISIT FOR IF_ELSE
    public Void visit(If_Else node, FunctionDefinition param) {

        /*

              execute[[IfElse: statement1 -> expression statement2* statement3*]]() =
                    int elseBody = cg.getLabel();
                    int end = cg.getLabel();
                    value[[expression]]()
                    <jz> elseBody
                    statement2*.forEach(stmnt -> execute[[stmnt]])
                    <jmp> end
                    <label> elseBody <:>
                    statement3*.forEach(stmnt -> execute[[stmnt]])
                    <label> end <:>

         */
        String elseBody = cg.getLabel();
        String end = cg.getLabel();

        node.getConditionalExp().accept(valueVisitor,param);
        cg.jz(elseBody);
        node.getIfBody().forEach(stmnt -> stmnt.accept(this,param));
        cg.jmp(end);

        cg.printLabel(elseBody);
        node.getElseBody().forEach(stmnt -> stmnt.accept(this,param));
        cg.printLabel(end);
        return null;
    }

    //VISIT FOR WHILE
    public Void visit(While node, FunctionDefinition param) {

        String condition = cg.getLabel();
        String end = cg.getLabel();
        cg.printLabel(condition);
        node.getConditionalExp().accept(valueVisitor,param);
        cg.jz(end);
        node.getWhileBody().forEach(stmnt -> stmnt.accept(this,param));
        cg.jmp(condition);
        cg.printLabel(end);
        return null;
    }
}
